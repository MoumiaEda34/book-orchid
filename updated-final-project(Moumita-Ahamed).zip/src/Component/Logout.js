// Logout.js
import React from 'react';


const Logout = () => {
  
  return (
    <div>
      <h2>Logging you out...</h2>
    </div>
  );
};

export default Logout;  // Ensure you are using 'default export'
